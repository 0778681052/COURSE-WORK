﻿Public Class HumanResourceInformationForm
    Public Class Employee
        Public Property EmployeeID As Integer
        Public Property EmployeeName As String
        Public Property JobTitle As String
        Public Property Performance As String
        Public Property Training As String
        Public Property Attendance As String
        Public Property Allowance As Decimal
        Public Property Salary As Decimal
        Public Property TotalPay As Decimal

    End Class
    Private Employees As New List(Of Employee)

    Private Sub BtnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click
        'Get input from the user
        Dim employeeId As Integer = txtEmployeeID.Text
        Dim employeeName As String = txtEmployeeName.Text
        Dim jobTitle As String = txtJobTitle.Text
        Dim performance As String = txtPerformance.Text
        Dim training As String = txtTraining.Text
        Dim attendance As String = txtAttendance.Text
        Dim allowance As Decimal = Convert.ToDecimal(txtAllowance.Text)
        Dim salary As Decimal = Convert.ToDecimal(txtSalary.Text)
        Dim totalPay As Decimal = salary + allowance

        ' Calculate totalpay

        txtTotalPay.Text = totalPay

        'Create a new employee object
        Dim newEmployee As New Employee With {
            .EmployeeID = employeeId,
            .EmployeeName = employeeName,
            .JobTitle = jobTitle,
            .Performance = performance,
            .Training = training,
            .Attendance = attendance,
            .Allowance = allowance,
            .Salary = salary,
            .TotalPay = totalPay
            }

        ' Add new employe to the list
        Employees.Add(newEmployee)

        'display to the user
        MessageBox.Show("Added Successfully!")

        'Clear fields
        ClearEmployeeFields()

        'Update list view
        UpdateEmployeeListView()


    End Sub

    Private Sub UpdateEmployeeListView()

        lvEmployees.Items.Clear()

        For Each Employee In Employees
            Dim item As New ListViewItem({Employee.EmployeeID.ToString(), Employee.EmployeeName, Employee.JobTitle, Employee.Performance, Employee.Training, Employee.Attendance, Employee.Allowance.ToString("0.00"), Employee.Salary.ToString("0.00"), Employee.TotalPay.ToString("0.00")})
            lvEmployees.Items.Add(item)
        Next
    End Sub
    Private Sub ClearEmployeeFields()
        'Clear all input fields
        txtEmployeeID.Clear()
        txtEmployeeName.Clear()
        txtJobTitle.Clear()
        txtPerformance.Clear()
        txtTraining.Clear()
        txtAttendance.Clear()
        txtAllowance.Clear()
        txtSalary.Clear()
        txtTotalPay.Clear()
    End Sub

    Private Sub Label10_Click(sender As Object, e As EventArgs) Handles Label10.Click

    End Sub
End Class
