﻿Public Class CRMSystemForm
    Public Property CustomerID As Integer
    Public Property Name As String

    Public Property Email As String
    Public Property Contact As Double
    Public Property District As String

    'Create a list to store CRMSystem information
    Private CRMSystem As New List(Of CRMSystemForm)

    Private Sub btn_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        'Get input values from the user
        Dim custoomerID As Integer = Convert.ToInt32(txtCustomerID.Text)
        Dim Name As String = txtName.Text
        Dim Email As String = txtEmail.Text
        Dim Contact As Double = Convert.ToDouble(txtContact.Text)
        Dim District As String = txtDistrict.Text
        'Create a new CRMSystem object
        Dim NewCRMSystem As New CRMSystemForm With {
            .CustomerID = CustomerID,
             .Name = Name,
             .Email = Email,
             .Contact = Contact,
             .District = District
             }
        'Add the new CRMSystem to the list
        CRMSystem.Add(NewCRMSystem)
        'Display a message to the user
        MessageBox.Show("Customer's information Submitted Successfully")
        'Clear the input fields
        ClearFields()
    End Sub

    Private Sub ClearFields()
        'Clear all input fields
        txtCustomerID.Clear()
        txtName.Clear()
        txtEmail.Clear()
        txtContact.Clear()
        txtDistrict.Clear()


    End Sub

    Private Sub TxtDistrict_TextChanged(sender As Object, e As EventArgs) Handles txtDistrict.TextChanged

    End Sub
End Class
