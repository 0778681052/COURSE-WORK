﻿Public Class Form1


    Public Class Employee
        Public Property EmployeeID As Integer
        Public Property EmployeeName As String
        Public Property JobTitle As String
        Public Property Performance As String
        Public Property Training As String
        Public Property Allowance As Decimal
        Public Property Salary As Decimal
        Public Property TotalPay As Decimal
        Public Property Attendance As String
    End Class
    Private Employess As New List(Of Employee)
    Private txtEmployeeName As Object
    Private txtTraining As Object
    Private txtAllowance As Object
    Private txtTotal As Object
    Private ReadOnly txtEmployeeID As Object
    Private ReadOnly txtJobTitle As Object
    Private ReadOnly txtSalary As Object
    Public Property txtPerformance As Object
    Public Property txtAttendance As Object
    Public Property Employees As Object

    Private Sub btnSave_Click(sender As Object, e As EventArgs) Handles btnSave.Click

        'Get input from the user
        Dim employeeID As Integer = txtEmployeeID.Text
        Dim employeeName As String = txtEmployeeName.Text
        Dim jobTitle As String = txtJobTitle.Text
        Dim training As String = txtTraining.Text
        Dim performance As String = txtPerformance.Text
        Dim attendance As String = txtAttendance.Text
        Dim allowance As Decimal = Convert.ToDecimal(txtAllowance.Text)
        Dim salary As Decimal = Convert.ToDecimal(txtSalary.Text)
        Dim totalPay As Decimal = salary + allowance

        ' Calculate totalpay

        txtTotal.Text = totalPay

        ' create a new employee object
        Dim newEmployee As New Employee With {
            .EmployeeID = employeeID,
            .EmployeeName = employeeName,
            .JobTitle = jobTitle,
            .Performance = performance,
            .Training = training,
            .Attendance = attendance,
            .Allowance = allowance,
            .Salary = salary,
            .TotalPay = totalPay
            }

        ' Asdd new employee to the list
        Employees.Add(newEmployee)

        ' display to the user
        MessageBox.Show("Added Successfully")

        ' Clear fields
        ClearEmployeeFields()






    End Sub

    Private Sub ClearEmployeeFields()
        ' clear all input fields
        txtEmployeeID.clear()
        txtEmployeeName.clear()
        txtJobTitle.clear()
        txtPerformance.clear()
        txtTraining.clear()
        txtAttendance.clear()
        txtAllowance.clear()
        txtSalary.clear()
        txtTotal.clear()

        Throw New NotImplementedException()
    End Sub
End Class
