﻿Public Class FeedbackForm
    Class FeedbackForm
        Public Property CustomerName As String
        Public Property Address As String
        Public Property Feedback As String
        Public Property Rating As Integer
    End Class

    Private Sub btnsend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        Dim customerName As String = txtCustomerName.Text
        Dim address As String = txtAddress.Text
        Dim feedback As String = txtFeedback.Text
        Dim rating As Integer = Convert.ToInt16(txtRating.Text)


        MessageBox.Show("Thank you for your feedback")

        ClearFields()

    End Sub
    Private Sub ClearFields()
        txtCustomerName.Clear()
        txtAddress.Clear()
        txtFeedback.Clear()
        txtRating.Clear()
    End Sub
End Class
