﻿Public Class HumanResourceInformationSystem
    Public Class Employee
        Public Property EmployeeName As String
        Public Property Department As String
        Public Property Hoursworked As Decimal
        Public Property OvertimeHours As Decimal
        Public Property OvertimeRate As Decimal
        Public Property Salary As Decimal
        Public Property TotalPay As Decimal
    End Class
    Private Employees As New List(Of Employee)
    Private Sub btnAddsubmit_Click(sender As Object, e As EventArgs) Handles btnSubmit.Click
        ' Get input values from the user
        Dim EmployeeName As String = txtEmployeeName.Text
        Dim Department As String = txtDepartment.Text
        Dim HoursWorked As Decimal = Convert.ToDecimal(txtHoursWorked.Text)
        Dim OvertimeHours As Decimal = Convert.ToDecimal(txtOvertimeHours.Text)
        Dim OvertimeRate As Decimal = Convert.ToDecimal(txtOvertimeRate.Text)
        Dim Salary As Decimal = Convert.ToDecimal(txtSalary.Text)
        Dim regularPay As Decimal = Salary * HoursWorked
        Dim overtimePay As Decimal = OvertimeHours * OvertimeRate
        Dim TotalPay As Decimal = regularPay + overtimePay
        ' Create a new human resource information system object
        Dim newEmployee As New Employee With {
           .EmployeeName = EmployeeName,
           .Department = Department,
            .Hoursworked = HoursWorked,
            .OvertimeHours = OvertimeHours,
            .OvertimeRate = OvertimeRate,
            .Salary = Salary,
            .TotalPay = TotalPay
          }
        ' Calculate total pay 
        newEmployee.TotalPay = CalculateTotalPay(Salary, HoursWorked, OvertimeHours, OvertimeRate)
        ' Add the new employee to the list
        Employees.Add(newEmployee)
        txtTotalPay.Text = TotalPay
        ' Display message to the user
        MessageBox.Show("Employee information added successfully!")
        ' Clear the input fields
        ClearEmployeesFields()
        ' Update the employees list view
        UpdateEmployeesListView()
    End Sub
    Private Function CalculateTotalPay(salary As Decimal, overtimeHours As Decimal, hoursworked As Decimal, overtimeRate As Decimal) As Decimal
        ' Calculate total pay including overtime 
        Dim regularPay As Decimal = salary * hoursworked
        Dim overtimePay As Decimal = overtimeHours * overtimeRate
        Dim totalPay As Decimal = regularPay + overtimePay
        Return totalPay
    End Function
    Private Sub UpdateEmployeesListView()
        ' Clear the existing items in the list view
        'lvEmployees.Items.Clear()
        ' Add each employee to the list view
        For Each Employee In Employees
            Dim item As New ListViewItem({Employee.EmployeeName, Employee.Department, Employee.Salary.ToString("0.00"), Employee.Hoursworked.ToString("0.00"), Employee.OvertimeHours.ToString("0.00"), Employee.OvertimeRate.ToString("0.00")})
            'lvEmployees.Items.Add(item)
        Next
    End Sub
    Private Sub ClearEmployeesFields()
        ' Clear all input fields
        txtEmployeeName.Clear()
        txtDepartment.Clear()
        txtSalary.Clear()
        txtHoursWorked.Clear()
        txtOvertimeHours.Clear()
        txtOvertimeRate.Clear()
        txtTotalPay.Clear()
    End Sub
End Class

