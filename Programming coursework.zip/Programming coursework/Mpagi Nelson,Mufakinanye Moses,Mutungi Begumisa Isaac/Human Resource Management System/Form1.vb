﻿Public Class HRIS
    Public Property Name As String
    Public Property Department As String
    Public Property HoursWorked As Decimal
    Public Property Salary As Decimal

    Private Sub BtnTotalPay_Click(sender As Object, e As EventArgs) Handles btnTotalPay.Click

    End Sub
End Class
Friend Class Employee
    Public Property Name As String
    Public Property Department As String
    Public Property HoursWorked As Decimal
    Public Property Salary As Decimal
End Class
Public Class Human_Resource_Information_System
    Private HRIS As New List(Of HRIS)
    Private txtName As Object
    Private txtDepartment As Object
    Private txtHoursWorked As Object
    Private txtSalary As Object
    Private Sub BtnTotalPay_Click(sender As Object, e As EventArgs) Handles btnTotalPay.Click
        'Get input values from the user
        Dim Name As String = txtName.Text
        Dim Department As String = txtDepartment.Text
        Dim HoursWorked As Decimal = txtHoursWorked.Text
        Dim Salary As Decimal = txtSalary.Text
        Dim totalPay As Decimal
        'Create a new employee object
        Dim newEmployee As New Employee With {
            .Name = Name,
            .Department = Department,
            .HoursWorked = HoursWorked,
            .Salary = Salary
            }
        'Calculate total pay
        totalPay = HoursWorked * Salary
        MessageBox.Show(totalPay)
    End Sub

    Function totalPay() As Decimal
        Throw New NotImplementedException()
    End Function
End Class
